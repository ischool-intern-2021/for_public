# -*- coding: utf-8 -*-
"""
Created on Mon Feb 24 10:11:29 2020

@author: use
"""

import matplotlib.pyplot as plt

#OpenCVを利用する（cv2をインポート）
import cv2

#カスケードファイルの読み込み
cascade_file = "haarcascades/haarcascade_frontalface_alt2.xml"

#カスケードファイルを利用した検出器を定義
cascade = cv2.CascadeClassifier(cascade_file)

#画像ファイルを読み込み
image_file = cv2.imread("testimage.jpg")

#GrayScaleに変換
img_gray = cv2.cvtColor(image_file, cv2.COLOR_BGR2GRAY)

#detectMultiScaleで検出
face_list = cascade.detectMultiScale(img_gray, minSize=(100,100))

#検出できた顔の数
print(len(face_list))

#顔部分に枠を作成
for (x,y,w,h) in face_list:
  point_from = (x, y)
  point_to = (x + w, y + h)
  color = (255,0,0)
  cv2.rectangle(image_file,point_from,point_to,color,thickness=5)

plt.imshow(cv2.cvtColor(image_file, cv2.COLOR_BGR2RGB))
plt.show()