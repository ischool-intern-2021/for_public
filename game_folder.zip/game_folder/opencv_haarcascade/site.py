import cv2
import numpy as np
import sys
#import time

def main():
    """
    webcameraとの通信を確立する
    """
    #webカメラの読み込みを開始する。
    try:
        # カメラにアクセスできるかを確認。webcameraであればどれでもこのサイズで読み込むようだ。
        cap = cv2.VideoCapture(0)
        ret, frame = cap.read()
    except:
        print("Can't access to webcamera")#前回異常終了した場合などにはアクセスが拒否される。
        cap.release()
        sys.exit()
        return 0
    
    #一度通信がうまくいった場合のみ画像処理
    main_function(cap)
    cap.release()#webcameraとの通信終了。
    cv2.destroyAllWindows()#opencvによる描画終了。
    sys.exit()#本来は推奨されない通信の終了方法。pythonファイルを強制的に終了させる

def main_function(cap):
    """
    画像処理
    """
    #resize_ratio = 0.5
    cascPath = "haarcascades/haarcascade_frontalface_default.xml"
    eyePath = "harrcascades/haarcascade_eye.xml"
    smilePath = "haarcascades/haarcascade_smile.xml"
    faceCascade = cv2.CascadeClassifier(cascPath)
    eyeCascade = cv2.CascadeClassifier(eyePath)
    smileCascade = cv2.CascadeClassifier(smilePath)

    font = cv2.FONT_HERSHEY_SIMPLEX
    
    while(cap.isOpened()):
        # フレームを取得
        ret, frame = cap.read()
        #まれにウェブカメラから取得した画像がnoneの時がある。そのままopencvに渡すと異常終了するのでそれを防ぐ。
        if isinstance(frame,type(None)) == True:
            print("Can't acess webcamera")
            break
        else:
            k = 0 #条件に合うものが一つも見つからないときはopencvの表示を飛ばす。表示でエラーが出てしまう。
            frame3 = frame.copy()#ndim = 3,dtype=np.uint8,shape=(480,640,3)
            #以降はれサイズをしたいときのみ
            #resize = (int(640 * resize_ratio), int(480 * resize_ratio))
            #frame3 = cv2.resize(frame3,resize)
            #size = frame3.shape
            #white_img = np.zeros(size, dtype=np.uint8) #ndim=3,shape=(480,640,3)
            #GrayScaleに変換
            img_gray = cv2.cvtColor(frame3, cv2.COLOR_BGR2GRAY)
            
            #detectMultiScaleで検出
            face_list = faceCascade.detectMultiScale(img_gray, minSize=(100,100))
            
            for (x, y, w, h) in face_list:
                cv2.rectangle(frame3, (x, y), (x+w, y+h), (255, 0, 0), 3)
                roi_gray = img_gray[y:y+h, x:x+w]
                roi_color = frame3[y:y+h, x:x+w]
                cv2.putText(frame3,'Face',(x, y), font, 2,(255,0,0),5)
                
                if len(roi_gray) > 0:
                    smile = smileCascade.detectMultiScale(roi_gray,
                                                          scaleFactor= 1.16,
                                                          minNeighbors=35,
                                                          minSize=(25, 25),
                                                          flags=cv2.CASCADE_SCALE_IMAGE)
                    for (sx, sy, sw, sh) in smile:
                        cv2.rectangle(roi_color, (sh, sy), (sx+sw, sy+sh), (255, 0, 0), 2)
                        cv2.putText(frame3,'Smile',(x + sx,y + sy), 1, 1, (0, 255, 0), 1)
                    
                    """
                    eyes = eyeCascade.detectMultiScale(roi_gray)
                    
                    for (ex,ey,ew,eh) in eyes:
                        cv2.rectangle(roi_color,(ex,ey),(ex+ew,ey+eh),(0,255,0),2)
                        cv2.putText(frame3,'Eye',(x + ex,y + ey), 1, 1, (0, 255, 0), 1)
                    """

            cv2.putText(frame,'Number of Faces : ' + str(len(face_list)),(40, 40), font, 1,(255,0,0),2)
            k = 1
            # Display the resulting frame
            
            if k == 1:
                #ちゃんと描写できるときのみ表示する。
                cv2.imshow('Video', frame3)
                #cv2.imshow("test",white_img)
            #コマンドプロンプトでqキーが押されたら途中終了
            if cv2.waitKey(25) & 0xFF == ord('q'):
                break

if __name__ == '__main__':
    main()

#####################################################################



video_capture = cv2.VideoCapture(0)

while True:
    # Capture frame-by-frame
    ret, frame = video_capture.read()
    #まれにウェブカメラから取得した画像がnoneの時がある。そのままopencvに渡すと異常終了するのでそれを防ぐ。
    if isinstance(frame,type(None)) == True:
        print("Can't acess webcamera")
        break

    


